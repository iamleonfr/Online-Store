// Cart Page
import React from "react";
import { useLocation } from "react-router-dom";

const Cart = () => {
  const location = useLocation();
  const cart = location.state?.cart || [];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-8 text-center">Cart</h1>

      {cart.length > 0 ? (
        <ul className="space-y-4">
          {cart.map((product) => (
            <li
              key={product.id}
              className="flex items-center justify-between bg-white shadow-md rounded-lg p-4"
            >
              <div>
                <h2 className="text-lg font-semibold text-gray-800">
                  {product.title}
                </h2>
                <p className="text-gray-600">${product.price}</p>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-600 text-center">Your cart is empty.</p>
      )}
    </div>
  );
};

export default Cart;
