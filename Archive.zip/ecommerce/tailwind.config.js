export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}", // Ensures Tailwind works in React components
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};